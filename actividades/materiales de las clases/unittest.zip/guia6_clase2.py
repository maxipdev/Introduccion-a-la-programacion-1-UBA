def volumen_esfera(radio:float) -> float:
    #aproximamos pi a 3,14
    res: float = 4/3 * 3.14 * radio**3
    return res


def triada_pitagorica(a: int, b: int, c:int) -> bool:
    suma: int = a**2 + b**2
    res: bool = suma == c*2
    return res